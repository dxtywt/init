#!/usr/bin/python
#  -*- coding:utf8 -*-

import os
import re
import sys
import time
import datetime
import logging
import logging.handlers
import cPickle
import hashlib

BASE_PATH = os.path.dirname(__file__)
sys.path.append(BASE_PATH)

LOG_FILE = BASE_PATH + '/log/log_monitor.log'
DATA_PATH = BASE_PATH + '/data/'

# init logger
logger=logging.getLogger()
handler = logging.handlers.TimedRotatingFileHandler(LOG_FILE, when='H', interval=1, backupCount=24)
formatter = logging.Formatter('%(levelname)-5s %(asctime)s %(filename)s %(lineno)-4d %(message)s')
handler.setFormatter(formatter)
logger.addHandler(handler)
logger.setLevel(logging.DEBUG)

class LogMonitor(object):
    def __init__(self, fname, regex, type, exRegex):
        self.fname     = os.path.abspath(fname)
        self.realFname = datetime.datetime.now().strftime(self.fname)
        self.regex     = regex.replace('\\\\', '\\')
        self.exRegex   = exRegex.replace('\\\\', '\\') if exRegex else None
        self.type      = type
        self.file      = None
        self.regulars  = {
            self.regex   : re.compile(self.regex),
            self.exRegex : re.compile(self.exRegex) if exRegex else None
        }

    def getPickle(self):
        "获取存放文件读取位置记录的文件名"
        md5    = hashlib.md5(self.fname + self.regex).hexdigest()
        pickle = DATA_PATH + md5 + '.pickle'
        logger.debug("get pickle of file:%s regex:%s return:%s" % (self.fname, self.regex, pickle))
        return pickle

    def setPostion(self, pos):
        "保存日志读取的位置,便于下次运行时继续读取"
        if not os.path.exists(DATA_PATH):
            os.makedirs(DATA_PATH)
        pickle = self.getPickle()
        try:
            f = open(pickle, 'w')
            stat = os.stat(self.realFname)
            record = {
                'ino' : stat.st_ino,
                'pos' : pos
            }
            cPickle.dump(record, f)
            f.close()
            logger.debug('write postion:%s to pickle: %s success' % (record, pickle)) 
            return True
        except Exception,e:
            logger.error('open pickle: %s to write postion exception: %s' % (pickle, e)) 
            return False

    def getPostion(self):
        "加载上次运行时读取到的位置,继续读取"
        pickle = self.getPickle()
        if not os.path.isfile(pickle):
            logger.warning('pickle: %s does not exsit, return 0' % pickle) 
            return 0
        try:
            f = open(pickle, 'r')
            record = cPickle.load(f)
            f.close()
            stat = os.stat(self.realFname)
            if record['ino'] == stat.st_ino:
                pos = record['pos']
            else:
                pos = 0
            logger.debug('get postion from pickle: %s return %s' % (pickle, pos)) 
            return pos
        except Exception,e:
            logger.error('open pickle: %s to load postion exception: %s, ruturn 0' % (pickle, e))
            return 0

    def open(self, fname):
        '尝试打开文件,失败返回None'
        try:
            return open(fname)
        except Exception,e:
            logger.error('open file: %s exception: %s, ruturn None' % (fname, e))
            return None

    def getValueByRe(self, regex, line):
        """
        function: 用正则从一行日志中过滤出需要的值
        args: regex -> 编译后的正则表达式 
              line  -> 要处理的日志，通常为一行
        return：正则过滤出的值，成功则返回提取的值，如果未做提取，仅作匹配则返回1，失败则返回0
        author: 翟鑫瑞
        """
        ret = 0
        try:
           result = self.regulars[regex].search(line)
           if result:
               try:
                   ret = result.group(1)
               except:
                   ret = 1
           else:
               ret = 0
           ret = float(ret)
        except Exception, e:
           logger.error('regex: %s return 0. The line is %s' % (regex, line))
           ret = 0

        #logger.debug('regex: %s return %s. The line is %s' % (regex, ret, line))
        return ret

    def analyze(self):
        "分析日志"
        result = 0
        # 打开日志
        fname = self.realFname
        f = self.open(fname)
        if f is None:
            logger.error('open log file: %s error.' % fname)
            return result
        # 跳到上次读取的位置
        try:
            f.seek(self.getPostion())
        except:
            f.seek(0)

        # 开始计算
        logger.debug('analyze log from line:%d by regex:%s' % (self.getPostion(), self.regex))
        if 'sum' == self.type:
            sum = 0.0
            while 1:
                line = f.readline()
                if not line:
                    break
                if self.exRegex and self.regulars[exRegex].search(line):
                    continue
                v = self.getValueByRe(self.regex, line)
                sum += v
            result = sum
        elif 'avg' == self.type:
            sum = cnt = 0.0
            while 1:
                line = f.readline()
                if self.exRegex and self.regulars[exRegex].search(line):
                    continue
                cnt += 1
                if not line:
                    break
                v = self.getValueByRe(self.regex, line)
                sum += float(v)
            result = sum / cnt
        else:
            logger.error('calculate type error, type:%s' % self.type)

        # 保存当前读取到的位置
        pos = f.tell()
        self.setPostion(pos)
        f.close()

        logger.info("analyze log success, return: %s" % result)
        return result
      

if __name__ == '__main__':
    logger.info("receive params: " + repr(sys.argv))
    if len(sys.argv) < 4:
        logger.error('params error: %s' % str(sys.argv))
        sys.exit()
    filename  = sys.argv[1]
    regex     = sys.argv[2]
    type      = sys.argv[3]
    if len(sys.argv) == 5 and len(sys.argv[4]) > 0 :
        exRegex = sys.argv[4] 
    else:
        exRegex = None
    logger.debug('receive exRegex: %s' % exRegex)
    logmonitor = LogMonitor(filename, regex, type, exRegex)
    print logmonitor.analyze()
    





