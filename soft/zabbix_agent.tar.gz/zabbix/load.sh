#!/bin/bash

#get Current Dir
this_dir=$PWD
dirname $0|grep "^/" >/dev/null
if [ $? -eq 0 ];then
        this_dir=$(dirname $0)
else
        dirname $0|grep "^\." >/dev/null
        retval=$?
        if [ $retval -eq 0 ];then
                this_dir=$(dirname $0|sed "s#^.#$this_dir#")
        else
                this_dir=$(dirname $0|sed "s#^#$this_dir/#")
        fi
fi

cd $this_dir || exit

conf=$this_dir/etc/zabbix_agentd.conf

start() {
    # 启动的时候先做变量替换
    innerIp=$(/sbin/ifconfig |grep -Po 'addr:10.\d+.\d+.\d+'|awk -F: '{print $2}')
    sed -i "s,{{HOSTNAME}},$innerIp,g" $conf 
    sbin/zabbix_agentd
}

stop() {
    killall -9 zabbix_agentd 2>/dev/null
}

case "X$1" in
	Xstart)
                stop
		start
		echo "Done!"
		;;
	Xstop)
		stop
		echo "Done!"
		;;
	*)
		echo "Usage: $0 {start|stop}"
		;;
esac

cd - > /dev/null


